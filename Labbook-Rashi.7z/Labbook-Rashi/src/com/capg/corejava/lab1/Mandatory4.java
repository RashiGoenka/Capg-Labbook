package com.capg.corejava.lab1;

import java.util.Scanner;

public class Mandatory4 {
	
	public boolean checkNumber(int n)
	{
		boolean t=false;
		for(int i=n;i>0;i=i/2)
		{
			if(i==2)
			{
				t=true;
				break;
			}
			if(i%2==0)
				t=true;
			else
			{
				t=false;
				break;
			}
		}
		return t;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scr= new Scanner(System.in);
		System.out.println("Enter the number");
		int n= scr.nextInt();
		Mandatory4 m1= new Mandatory4();
		if(m1.checkNumber(n))
		 System.out.println(n+" is power of 2");
		else
			System.out.println(n+" is not power of 2");
		scr.close();

	}

}
