package com.capg.corejava.lab2;

import java.util.Scanner;
public class Mandatory3 {
	
	public int[] getSorted(int [] arr)
	{
		for(int i=0;i<arr.length;i++)
		{
			int num=0;
			for(int j=arr[i];j>0;j/=10)
			{
				num=num*10+j%10;
			}
			arr[i]=num;
		}
		for(int i=0;i<arr.length;i++)
		{
			for(int j=i+1; j<arr.length;j++)
			{
				if(arr[i]>arr[j])
				{
					int temp=arr[i];
					arr[i]=arr[j];
					arr[j]=temp;
				}
			}
		}
		
		return arr;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scr= new Scanner(System.in);
		int []arr;
		int n;
		System.out.println("enter no of elements");
		n=scr.nextInt();
		arr= new int[n];
		for(int i=0;i<n;i++)
		{
			System.out.println("Enter element for arr["+i+"]");
			arr[i]=scr.nextInt();
		}
		System.out.println("Array before sorting:");
		for(int i=0;i<n;i++)
		{
			System.out.print(arr[i]+" ");
		}
		System.out.println();
		Mandatory3 m1= new Mandatory3();
		System.out.println("After reversing and sorting:");
		int []ar=m1.getSorted(arr);
		for(int i=0;i<n;i++)
		{
			System.out.print(ar[i]+" ");
		}
		scr.close();

	}

}
