package com.capg.corejava.lab2;

import java.util.Scanner;
public class Mandatory4 {
	
	public int modifyArray(int [] arr)
	{
		
		for(int i=0;i<arr.length;i++)
		{
			for(int j=i+1; j<arr.length;j++)
			{
				if(arr[i]<arr[j])
				{
					int temp=arr[i];
					arr[i]=arr[j];
					arr[j]=temp;
				}
			}
		}
		int[] ar= new int[arr.length];
		int j=0;
		   for(int i=0;i<arr.length-1;i++)
		   {
			 if(arr[i]!=arr[i+1]);
			 {
				 ar[j]=arr[i];
				 j++;
			 }
				
		   }
		   for(int i=0;i<arr.length;i++)
		   {
			  arr[i]=ar[i];
		   }
		   
			
		return j;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scr= new Scanner(System.in);
		int []arr;
		int n;
		System.out.println("enter no of elements");
		n=scr.nextInt();
		arr= new int[n];
		for(int i=0;i<n;i++)
		{
			System.out.println("Enter element for arr["+i+"]");
			arr[i]=scr.nextInt();
		}
		System.out.println("Array before sorting:");
		for(int i=0;i<n;i++)
		{
			System.out.print(arr[i]+" ");
		}
		System.out.println();
		Mandatory4 m1= new Mandatory4();
		System.out.println("After removing duplicates and sorting:");
		int j=m1.modifyArray(arr);
		for(int i=0;i<j;i++)
		{
			System.out.print(arr[i]+" ");
		}
		scr.close();

	}

}
