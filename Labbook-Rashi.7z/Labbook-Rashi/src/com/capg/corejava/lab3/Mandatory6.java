package com.capg.corejava.lab3;

import java.util.*;

public class Mandatory6 {
	
	public boolean checkString(String s)
	{
		boolean t=false;
		for(int i=0;i<s.length()-1;i++)
		{
			if(s.charAt(i) <= s.charAt(i+1))
			{
				t=true;
				
			}
			else
			{
				t=false;
				break;
			}
		}
		return t;
	}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scr=new Scanner (System.in);
		String s;
		System.out.println("Enter the string");
		s=scr.nextLine();
		Mandatory6 m6=new Mandatory6();
		if(m6.checkString(s))
		System.out.println(s+" is an increasing string");
		else
			System.out.println(s+" is not an increasing string");
		
		scr.close();
		

	}

}
