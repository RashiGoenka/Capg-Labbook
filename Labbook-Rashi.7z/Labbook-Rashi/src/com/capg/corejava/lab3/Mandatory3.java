package com.capg.corejava.lab3;

import java.util.*;

public class Mandatory3 {
	
	public String alterString(String s)
	{
		char ch;
		String str="";
		for(int i=0;i<s.length();i++)
		{
			ch=s.charAt(i);
			if(ch=='A'|| ch=='E' || ch=='I'|| ch=='O' ||ch=='U'|| 
					ch=='a' || ch=='e'|| ch=='i'||ch=='o'|| ch=='u')
			{
				
				str+=ch;
				
			}
			else
			{
				ch+=1;
				str+=ch;
			}
		}

		return str;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scr=new Scanner (System.in);
		String s;
		System.out.println("Enter the string");
		s=scr.nextLine();
		Mandatory3 m2=new Mandatory3();
		System.out.println(m2.alterString(s));
		scr.close();
		

	}

}
