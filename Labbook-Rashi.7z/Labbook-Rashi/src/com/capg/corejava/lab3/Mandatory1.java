package com.capg.corejava.lab3;

import java.util.*;

public class Mandatory1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scr=new Scanner (System.in);
		String s;
		int sum=0;
		System.out.println("Enter the line of integer");
		s=scr.nextLine();
		StringTokenizer st=new StringTokenizer(s," ");
		while(st.hasMoreTokens())
		{
			String temp=st.nextToken();
			System.out.println(Integer.parseInt(temp));
			sum+= Integer.parseInt(temp);
			
		}
		System.out.println("sum: "+sum);
		scr.close();
		

	}

}
