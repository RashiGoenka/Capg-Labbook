package com.capg.corejava.lab3;

import java.util.*;

public class Mandatory5 {
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scr=new Scanner (System.in);
		String s;
		System.out.println("Enter the string");
		s=scr.nextLine();
		int ch=0,cw=0,cl=1;
		for(int i=0;i<s.length();i++)
		{
			if(s.charAt(i)==' ')
				cw++;
			if(s.charAt(i)=='\n')
				cl++;
			ch++;
		}
		System.out.println("No. of characters: "+ch);
		System.out.println("No. of words: "+cw);
		System.out.println("No. of lines: "+cl);
		scr.close();
		

	}

}
