package com.capg.corejava.lab3;

import java.util.*;

public class Mandatory7 {
	
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scr=new Scanner (System.in);
		String s;
		//System.out.println("Enter the date in DD/MM/YYYY format");
		//s=scr.nextLine();
		
		Date toDay=new Date();
		System.out.println(toDay);
		System.out.println(toDay.getTime());
		Date d2=new Date(24*60*60*1000);
		System.out.println(d2);
		long d=toDay.getTime()-d2.getTime();
		long y=(d/(10001*60*60*24))%365;
		long day=(d/(1000*60*60*24))%365;
		System.out.println(y+" years");
		System.out.println(day+" days");
		
		
		
		
		scr.close();
		

	}

}
