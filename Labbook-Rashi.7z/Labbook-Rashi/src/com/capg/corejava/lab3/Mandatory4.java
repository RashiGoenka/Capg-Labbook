package com.capg.corejava.lab3;

import java.util.*;

public class Mandatory4 {
	
	public int modifyNumber(int number1)
	{
		String st="";
		int i;
		String s=String.valueOf(number1);
		for(i=0;i<s.length()-1;i++)
		{
			int n1= s.charAt(i);
			int n2=s.charAt(i+1);
			st+=String.valueOf(Math.abs(n1-n2));
		}
		st+=s.charAt(i);
		
		

		return (Integer.parseInt(st)) ;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scr=new Scanner (System.in);
		int n;
		System.out.println("Enter the number");
		n=scr.nextInt();
		Mandatory4 m2=new Mandatory4();
		System.out.println(m2.modifyNumber(n));
		scr.close();
		

	}

}
