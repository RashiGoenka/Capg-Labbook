package com.capg.corejava.lab7;

import java.util.HashMap;
import java.util.List;

import com.cg.eis.bean.Employee;
import com.cg.eis.service.EmployeeDAO;

public class EmployeeService {
	
	public HashMap  addEmployeeService(int empId,String empname,double salary,String designation)
	{
	   String insuranceScheme=" ";
	   
	   if(salary>5000 && salary<20000)
	{
		   insuranceScheme="SchemeC";
		   }
	   else if (salary>=20000 && salary<40000)
		{
			   insuranceScheme="SchemeB";
			   }
	   else if (salary>=40000)
		{
			   insuranceScheme="SchemeA";
			   }
	   else 
		{
		   insuranceScheme="NO Scheme";
		   }
	   Employee employeebean=new Employee();
	   employeebean.setempId(empId);
	   employeebean. setsalary(salary) ;
	   employeebean.setempname(empname);
	   employeebean.setdesignation(designation);
	  employeebean.setinsuranceScheme(insuranceScheme);
	  
	  HashMap<Integer,List> new_hmap = new HashMap<Integer,List>();
      EmployeeDAO employeedao=new EmployeeDAO();
	  new_hmap.putAll(employeedao.addEmployee(employeebean));

	return new_hmap;
}
	public HashMap delEmployeeService(int empId, HashMap hm)
	{
		HashMap<Integer,List> new_hmap = new HashMap<Integer,List>();
	      EmployeeDAO employeedao1=new EmployeeDAO();
		  new_hmap.putAll(employeedao1.delEmployee(empId,hm));
		  return new_hmap;
	}
}