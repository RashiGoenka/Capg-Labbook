package com.cg.eis.pl;
import com.capg.corejava.lab7.EmployeeService;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;


public class EmployeMainController {
	public static void main(String[] args) {

	int empId=0;
	String empname=null;
	double salary=0;
	String designation=null;
	String insuranceScheme=" ";
	HashMap<Integer,List> result_hmap = new HashMap<Integer,List>();
	List output_list = new ArrayList(); 
	Scanner sc=new Scanner(System.in);
	System.out.println("enter no of employee:");
	int n=sc.nextInt();
	 EmployeeService emps= new EmployeeService();
	for(int i=0;i<n;i++)
	{
		try {
	System.out.println("Enter Employee ID :");
	empId=sc.nextInt();
	
	System.out.println("Enter Employee Name :");
	 
     empname=sc.next();
	
	System.out.println("Enter Employee Salary :");
	
	salary=sc.nextDouble();
	
	System.out.println("Enter Employee Designation :");
	
	 designation=sc.next();
		}
		catch(Exception e) {
			System.out.println("Invalid Input");
			System.exit(0);
		}
	
	//System.out.println("Enter insuranceScheme :");
	//insuranceScheme=sc.next();
	 
	
	 result_hmap.putAll(emps.addEmployeeService(empId,empname,salary,designation));
	
	}
	System.out.println("Name of scheme to show the details of employees ");
	insuranceScheme = sc.next();
	//sc.close();
	//System.out.println("Main controller Return value is : "+result_hmap);
	for(Map.Entry<Integer,List> entry : result_hmap.entrySet())
	{
		//System.out.println("Key "+entry.getKey()+" values"+entry.getValue());
		output_list = entry.getValue();
		//System.out.println(insuranceScheme+" "+output_list.get(4)+" "+insuranceScheme.equals(output_list.get(4)));
		if(insuranceScheme.equals(output_list.get(4)))
		{
			System.out.println("Employee id "+output_list.get(0));
			System.out.println("Employee name is "+output_list.get(1));
			System.out.println("Employee designation "+output_list.get(2));
			System.out.println("Employee salary "+output_list.get(3));
			System.out.println("Employee health insurance scheme is "+output_list.get(4));
		}
			
		
		
	}
	System.out.println("Enter the id to be deleted");
	empId=sc.nextInt();
	//EmployeeService emps1= new EmployeeService();
	 result_hmap.putAll(emps.delEmployeeService(empId,result_hmap));
	 for(Map.Entry<Integer,List> entry : result_hmap.entrySet())
		{
		 System.out.println("Key "+entry.getKey()+" values"+entry.getValue());
		}
}
}
