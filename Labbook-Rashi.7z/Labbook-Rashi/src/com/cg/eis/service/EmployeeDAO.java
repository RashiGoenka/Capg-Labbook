package com.cg.eis.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.cg.eis.bean.Employee;


public class EmployeeDAO {
	List emplist= new ArrayList();
	HashMap<Integer,List> hm=new HashMap<Integer,List>();
	public HashMap addEmployee(Employee employeebean)
	{
		
		
	 emplist.add(employeebean.getempId());
	 emplist.add(employeebean.getempname());
	 emplist.add(employeebean.getsalary());
	 emplist.add(employeebean.getdesignation());
	 emplist.add(employeebean.getinsuranceScheme());

	 System.out.println("Employee list :"+emplist );
	 hm.put(employeebean.getempId(),emplist);
	 
	/* System.out.println("employee Id :"+employeebean.getempId());
		System.out.println("name:"+employeebean.getempname());
		System.out.println("salary:"+employeebean.getsalary());
		System.out.println("designation :"+employeebean.getdesignation());
		System.out.println("insurance scheme :"+employeebean.getinsuranceScheme());
		
	 */
		return hm;
	}
	public HashMap delEmployee(int empId, HashMap empL)
	{
		hm.remove(empId,empL);
		return hm;
	}

}