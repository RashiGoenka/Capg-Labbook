

package com.cg.eis.bean;

import java.io.Serializable;
public class Employee implements Serializable {
	private int empId;
	private String empname;
	private double salary; 
	private String designation;
	private String insuranceScheme;
	
	public int  getempId() {
		return empId;
	}
	public void setempId(int empId) {
		this.empId = empId;
	}
	public String getempname() {
		return empname;
	}
	public void setempname(String empname) {
		this.empname = empname;
	}
	public double getsalary() {
		return salary;
	}
	public void setsalary(double salary) {
		this.salary = salary;
	}
	public String getdesignation() {
		return designation;
	}
	public void setdesignation(String designation) {
		this.designation = designation;
	}
	public String getinsuranceScheme()
	{
		return insuranceScheme;
		
	}
	public void setinsuranceScheme(String insuranceScheme)
	{
		this.insuranceScheme=insuranceScheme;
	}

}
